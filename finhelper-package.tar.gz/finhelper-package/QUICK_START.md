# FinHelper - Quick Start

1. Install Docker and Docker Compose
2. Run: ./scripts/deploy.sh
3. Open: https://localhost

That's it! 🎉
